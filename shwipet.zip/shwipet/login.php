<?php

    $name = $_POST["email"]
    $name = $_POST["password"]
    print_r($_POST);