<?php

    $name = $_POST["name"]
    $name = $_POST["email"]
    $name = $_POST["comment"]
    print_r($_POST);